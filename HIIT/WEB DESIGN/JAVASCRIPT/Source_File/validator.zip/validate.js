function theFormValidation(){
    const name = document.forms.name.value;
    const email = document.forms.email.value;
    const phone = document.forms.phone.value;
    const pass = document.forms.password.value;
    const cpass = document.forms.confirm_password.value;

    // if(name == ""){
    //     alert("A name field is required!")
    // }

    if(name == "")
{
    document.querySelector(".name-error").style.display = "block";
    return false;
}
if(isNaN(phone)){
    alert("Phone is not a number");
    return false;
}

if(pass !== cpass){
   document.querySelector(".pass-error").style.display = "block";
   return false;
}
}