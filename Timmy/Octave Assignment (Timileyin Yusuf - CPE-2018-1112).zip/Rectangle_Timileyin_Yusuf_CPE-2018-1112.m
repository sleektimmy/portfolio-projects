
printf("Welcome to the Rectangle Volume,Area and Perimeter Calculator")
printf("\n")
printf("-----------")
printf("\n")
l=input("Enter length of one side of the Rectangle: ");
w=input("Enter width of one side of the Rectangle: ");
a=w*l;
p=2*(w+l);
printf("Your results are as follows: ")
printf("\n")
printf("Area : %.1d ", a)
printf("\n")
printf("Perimeter : %.1d ", p)
printf("\n")
printf("Volume: The rectangle shape has no volume")
printf("\n")