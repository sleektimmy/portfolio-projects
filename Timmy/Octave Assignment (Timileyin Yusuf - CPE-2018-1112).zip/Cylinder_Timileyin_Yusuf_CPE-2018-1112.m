
printf("Welcome to the Cylinder Volume,Area and Perimeter Calculator")
printf("\n")
printf("-----------")
printf("\n")
r=input("Enter radius of the Cylinder: ");
h=input("Enter height of the Cylinder: ");
a=(2*pi*r*h)+(2*pi*r^2);
v=pi*r^2*h;
printf("Your results are as follows: ")
printf("\n")
printf("Area : %.3f ", a)
printf("\n")
printf("Volume:  %.3f ", v)
printf("\n")
printf("Perimeter : The Cylinder shape has no Perimeter")
printf("\n")