#This is a calculator for Area of a Square
printf("Welcome to the Square Volume,Area and Perimeter Calculator")
printf("\n")

l=input("Enter length of one side of the square: ");
a=l^2;
p=4*l;
printf("Your results are as follows: ")
printf("\n")
printf("Area : %.1d ", a)
printf("\n")
printf("Perimeter : %.1d ", p)
printf("\n")
printf("Volume: The square shape has no volume")
