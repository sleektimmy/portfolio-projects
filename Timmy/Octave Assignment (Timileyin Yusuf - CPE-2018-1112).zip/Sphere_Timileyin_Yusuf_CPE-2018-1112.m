
printf("Welcome to the Sphere Volume,Area and Perimeter Calculator")
printf("\n")
printf("-----------")
printf("\n")
r=input("Enter radius of the Sphere: ");
a=4*pi*r^2;
v=1.3*pi*r^3;
printf("Your results are as follows: ")
printf("\n")
printf("Area : %.3f ", a)
printf("\n")
printf("Volume:  %.3f ", v)
printf("\n")
printf("Perimeter : The Sphere shape has no Perimeter")
printf("\n")